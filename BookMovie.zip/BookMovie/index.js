const express = require('express');
const app = express();
const path = require("path");
const ejsmate = require("ejs-mate");
const methodoverride = require("method-override");


const session = require("express-session");
const flash = require("connect-flash");
const passport = require("passport");
const LocalStrategy = require("passport-local");

const mongoose = require("mongoose");
const mongoSanitize = require("express-mongo-sanitize");

app.use(express.static(path.join(__dirname, "public")));
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.urlencoded({ extended: true }));
app.use(methodoverride("_method"));
app.engine("ejs", ejsmate);

const MongoStore = require("connect-mongo");
const dbURL = "mongodb+srv://vipinkulkarni16:gjzMyhrICjO8JMqu@cluster0.j26jxla.mongodb.net/?retryWrites=true&w=majority";
mongoose.connect(dbURL, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  //useCreateIndex: true,
  //useFindAndModify: false,
});

const db = mongoose.connection;
db.on("error", console.error.bind(console, "connection error:"));
db.once("open", () => {
  console.log("DATABASE CONNECTED");
});

app.use(express.static(path.join(__dirname, "public")));
const secret = "thisshouldbeabettersecret";
const store = MongoStore.create({
  mongoUrl: dbURL,
  secret,
});
store.on("error", function (e) {
  console.log("SESSION STORE ERROR", e);
});
const sessionconfig = {
  store,
  name: "log",
  secret,
  resave: false,
  saveUninitialized: true,
  cookie: {
    httpOnly: true,
    // secure:true,
    expires: Date.now() + 1000 * 60 * 60 * 24 * 7,
    maxAge: 1000 * 60 * 60 * 24 * 7,
  },
};
app.use(session(sessionconfig));
app.use(flash());
app.use(passport.initialize());
app.use(passport.session());
app.use(mongoSanitize());

const User = require("./models/user");
passport.use(new LocalStrategy(User.authenticate()));

passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());
app.use((req, res, next) => {
    res.locals.currentuser = req.user;
    res.locals.success = req.flash("success");
    res.locals.error = req.flash("error");
    next();
  });
  
const {renderRegister, register, renderAdminLogin, renderLogin, login, logout} = require("./public/users");
const Movie = require("./models/movie");
//const Show = require("./models/show");

app.get("/signup", (req, res)=>{
    renderRegister(req, res);
})

app.get("/logout", (req, res, next)=>{
    logout(req, res, next);
})

app.get("/login/admin",(req, res)=>{
  renderAdminLogin(req, res);
})

app.get("/login/user",(req,res)=>{
    renderLogin(req, res);
})

app.get("/login", (req, res)=>{
    res.redirect("/login/user");
})

app.post("/login", passport.authenticate('local', {failureFlash:true, failureRedirect:'/login'}), login);

app.post("/register", (req, res)=>{
    register(req, res);
})

app.get("/bookings", (req, res)=>{
    res.render("bookings");
})

app.get("/movie/new", (req, res)=>{
    res.render("addmovie");
})

app.post("/movies", async (req, res)=>{
  if(res.locals.currentuser && res.locals.currentuser.admin){
    const movie = new Movie(req.body.movie);
    await movie.save();
    req.flash("success", "Successfully Added a new Movie");
    res.redirect(`/movie/${movie._id}`);
  }
})

app.post("/theatres", async (req, res)=>{
  if(res.locals.currentuser && res.locals.currentuser.admin){
    const movie = new Movie(req.body.movie);
    await movie.save();
    req.flash("success", "Successfully Added a new Theatre");
    res.redirect(`/theatre/${theatre._id}`);
  }
})

app.get("/movie/:id",async (req, res)=>{
    const movie = await Movie.findById(req.params.id);
    res.render("viewmovie", {movie});
})

app.get("/theatre/new", (req,res)=>{
    res.render("addtheatre");
})

app.get("/theatre/:id", async (req, res)=>{
  const theatre = await Movie.findById(req.params.id)
  res.render("viewtheatre", {theatre});
})

app.get("/",async (req, res)=>{
    const movies = await Movie.find({});
    res.render("home.ejs", {movies});
})

app.listen(3000, ()=>{
    console.log("Listening on Port 3000");
})