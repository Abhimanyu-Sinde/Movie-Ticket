const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const Movie = require("./movie");
const Theatre = require("./theatre")

const showSchema = new Schema({
    movie: {
        type: Movie,
        required: true
    },
    theatre:{
        type: Theatre,
        required: true
    },
    price:{
        type: Number,
        required: true
    },
    time:{
        type: String,
        required: true
    },
    tickets:{
        type: Number,
        required: true
    }
})

module.exports = mongoose.model('Show',showSchema);