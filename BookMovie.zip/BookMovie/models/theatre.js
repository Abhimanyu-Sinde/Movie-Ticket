const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const theatreSchema = new Schema({
    title: {
        type: String,
        required: true
    },
    description: String,
    location: {
        type: String,
        required: true
    }
})

module.exports = mongoose.model('Theatre',theatreSchema);