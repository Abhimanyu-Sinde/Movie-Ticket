const User = require('../models/user');

module.exports.renderRegister =  (req,res) => {
    res.render('signup');
}

module.exports.register = async (req,res,next) => {
    try{
        const {email, username, password} = req.body;
        const admin = true;
        const user = new User({email,username, admin});
        const registered = await User.register(user,password);
        req.login(registered, err => {
            if(err) return next(err);
            req.flash('success','Book a Movie Ticket!!');
            res.redirect('/');
        })
    } catch(e){
        req.flash('error',e.message);
        res.redirect('/signup');
    }
}

module.exports.renderLogin =  (req,res) => {
    res.render('userlogin');
}

module.exports.renderAdminLogin =  (req,res) => {
    res.render('adminlogin');
}

module.exports.login =  (req,res) => {
    req.flash('success','Welcome Back!');
    const redirectUrl = req.session.returnTo || '/';
    delete req.session.returnTo;
    res.redirect(redirectUrl);
}

module.exports.logout =  (req,res, next) => {
    req.logout((err) => {
        if (err) { return next(err);}
        req.flash('success','Logged You Out! GoodBye!')
        res.redirect('/');
    });
}